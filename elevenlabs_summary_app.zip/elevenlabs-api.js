// elevenlabs-api.js
// ElevenLabs APIとの連携を行うモジュール

import config from './config.js';

/**
 * ElevenLabs APIクライアントクラス
 */
class ElevenLabsAPI {
  constructor(apiKey = config.elevenlabs.apiKey, apiUrl = config.elevenlabs.apiUrl) {
    this.apiKey = apiKey;
    this.apiUrl = apiUrl;
    this.voiceId = config.elevenlabs.voiceId;
  }

  /**
   * テキストから音声を生成する
   * @param {string} text - 音声に変換するテキスト
   * @param {string} voiceId - 使用する音声ID（オプション）
   * @returns {Promise<Blob>} - 生成された音声データ（Blob形式）
   */
  async generateSpeech(text, voiceId = this.voiceId) {
    try {
      const url = `${this.apiUrl}/text-to-speech/${voiceId}`;
      
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'xi-api-key': this.apiKey
        },
        body: JSON.stringify({
          text: text,
          model_id: 'eleven_monolingual_v1',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.5
          }
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`ElevenLabs API Error: ${errorData.detail || response.statusText}`);
      }

      return await response.blob();
    } catch (error) {
      console.error('Error generating speech:', error);
      throw error;
    }
  }

  /**
   * 利用可能な音声のリストを取得する
   * @returns {Promise<Array>} - 利用可能な音声のリスト
   */
  async getVoices() {
    try {
      const url = `${this.apiUrl}/voices`;
      
      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'xi-api-key': this.apiKey
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`ElevenLabs API Error: ${errorData.detail || response.statusText}`);
      }

      const data = await response.json();
      return data.voices || [];
    } catch (error) {
      console.error('Error fetching voices:', error);
      throw error;
    }
  }

  /**
   * Blobデータをファイルに変換する
   * @param {Blob} blob - 音声データ（Blob形式）
   * @param {string} filename - ファイル名
   * @returns {File} - ファイルオブジェクト
   */
  blobToFile(blob, filename) {
    return new File([blob], filename, { type: blob.type });
  }
}

export default ElevenLabsAPI;
