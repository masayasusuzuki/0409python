// supabase-client.js
// Supabaseとの連携を行うモジュール

import config from './config.js';

/**
 * Supabaseクライアントクラス
 */
class SupabaseClient {
  constructor() {
    // Supabaseクライアントの初期化
    this.supabase = null;
    this.initialized = false;
  }

  /**
   * Supabaseクライアントを初期化する
   * @returns {Promise<void>}
   */
  async initialize() {
    if (this.initialized) return;

    try {
      // Supabase JSライブラリの動的読み込み
      if (typeof supabase === 'undefined') {
        await this.loadSupabaseLibrary();
      }

      // Supabaseクライアントの作成
      this.supabase = supabase.createClient(
        config.supabase.url,
        config.supabase.apiKey
      );
      
      this.initialized = true;
      console.log('Supabase client initialized');
    } catch (error) {
      console.error('Error initializing Supabase client:', error);
      throw error;
    }
  }

  /**
   * Supabase JSライブラリを動的に読み込む
   * @returns {Promise<void>}
   */
  loadSupabaseLibrary() {
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
      script.onload = resolve;
      script.onerror = () => reject(new Error('Failed to load Supabase library'));
      document.head.appendChild(script);
    });
  }

  /**
   * 音声ファイルをアップロードする
   * @param {File} file - アップロードするファイル
   * @returns {Promise<string>} - アップロードされたファイルのURL
   */
  async uploadAudio(file) {
    await this.initialize();
    
    try {
      const fileName = `${Date.now()}_${file.name}`;
      const { data, error } = await this.supabase.storage
        .from(config.supabase.bucket)
        .upload(fileName, file);

      if (error) throw error;

      // 公開URLを取得
      const { data: urlData } = this.supabase.storage
        .from(config.supabase.bucket)
        .getPublicUrl(fileName);

      return urlData.publicUrl;
    } catch (error) {
      console.error('Error uploading audio file:', error);
      throw error;
    }
  }

  /**
   * 要約データをデータベースに保存する
   * @param {string} text - 要約テキスト
   * @param {string} audioUrl - 音声ファイルのURL
   * @returns {Promise<Object>} - 保存されたデータ
   */
  async saveSummary(text, audioUrl) {
    await this.initialize();
    
    try {
      const { data, error } = await this.supabase
        .from(config.supabase.tableName)
        .insert([
          { 
            text: text, 
            audio_url: audioUrl,
            created_at: new Date().toISOString()
          }
        ])
        .select();

      if (error) throw error;
      return data[0];
    } catch (error) {
      console.error('Error saving summary:', error);
      throw error;
    }
  }

  /**
   * 要約データのリストを取得する
   * @param {number} limit - 取得する件数（デフォルト: 10）
   * @returns {Promise<Array>} - 要約データのリスト
   */
  async getSummaries(limit = 10) {
    await this.initialize();
    
    try {
      const { data, error } = await this.supabase
        .from(config.supabase.tableName)
        .select('*')
        .order('created_at', { ascending: false })
        .limit(limit);

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching summaries:', error);
      throw error;
    }
  }

  /**
   * 特定のIDの要約データを取得する
   * @param {number} id - 要約データのID
   * @returns {Promise<Object>} - 要約データ
   */
  async getSummaryById(id) {
    await this.initialize();
    
    try {
      const { data, error } = await this.supabase
        .from(config.supabase.tableName)
        .select('*')
        .eq('id', id)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error(`Error fetching summary with ID ${id}:`, error);
      throw error;
    }
  }
}

export default SupabaseClient;
