// app.js
// メインのアプリケーションロジック

import ElevenLabsAPI from './elevenlabs-api.js';
import SupabaseClient from './supabase-client.js';
import config from './config.js';

// アプリケーションクラス
class App {
  constructor() {
    this.elevenlabs = new ElevenLabsAPI();
    this.supabase = new SupabaseClient();
    this.currentAudioBlob = null;
    this.currentText = '';
    
    // DOM要素
    this.textForm = document.getElementById('text-form');
    this.summaryText = document.getElementById('summary-text');
    this.voiceSelect = document.getElementById('voice-select');
    this.generateBtn = document.getElementById('generate-btn');
    this.loadingIndicator = document.getElementById('loading-indicator');
    this.previewSection = document.getElementById('preview-section');
    this.previewText = document.getElementById('preview-text');
    this.previewAudio = document.getElementById('preview-audio');
    this.saveBtn = document.getElementById('save-btn');
    this.summariesList = document.getElementById('summaries-list');
    
    // イベントリスナーの設定
    this.initEventListeners();
    
    // 初期化
    this.initialize();
  }
  
  /**
   * アプリケーションの初期化
   */
  async initialize() {
    try {
      // Supabaseクライアントの初期化
      await this.supabase.initialize();
      
      // 音声リストの取得
      await this.loadVoices();
      
      // 保存された要約の読み込み
      await this.loadSummaries();
    } catch (error) {
      console.error('Initialization error:', error);
      this.showError('アプリケーションの初期化中にエラーが発生しました。');
    }
  }
  
  /**
   * イベントリスナーの設定
   */
  initEventListeners() {
    // テキスト送信フォーム
    this.textForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      await this.generateSpeech();
    });
    
    // 保存ボタン
    this.saveBtn.addEventListener('click', async () => {
      await this.saveSummary();
    });
  }
  
  /**
   * 利用可能な音声のリストを読み込む
   */
  async loadVoices() {
    try {
      const voices = await this.elevenlabs.getVoices();
      
      // セレクトボックスをクリア
      this.voiceSelect.innerHTML = '';
      
      // 音声オプションを追加
      voices.forEach(voice => {
        const option = document.createElement('option');
        option.value = voice.voice_id;
        option.textContent = voice.name;
        this.voiceSelect.appendChild(option);
      });
      
      // デフォルトの音声を選択
      if (config.elevenlabs.voiceId) {
        this.voiceSelect.value = config.elevenlabs.voiceId;
      }
    } catch (error) {
      console.error('Error loading voices:', error);
      
      // エラー時のフォールバックオプション
      this.voiceSelect.innerHTML = `
        <option value="${config.elevenlabs.voiceId}">デフォルト音声</option>
      `;
    }
  }
  
  /**
   * 保存された要約のリストを読み込む
   */
  async loadSummaries() {
    try {
      const summaries = await this.supabase.getSummaries();
      
      if (summaries.length === 0) {
        this.summariesList.innerHTML = '<p class="empty-message">保存された要約はありません</p>';
        return;
      }
      
      // リストをクリア
      this.summariesList.innerHTML = '';
      
      // 要約カードを追加
      summaries.forEach(summary => {
        const card = this.createSummaryCard(summary);
        this.summariesList.appendChild(card);
      });
    } catch (error) {
      console.error('Error loading summaries:', error);
      this.showError('要約の読み込み中にエラーが発生しました。');
    }
  }
  
  /**
   * 要約カードを作成する
   * @param {Object} summary - 要約データ
   * @returns {HTMLElement} - 要約カード要素
   */
  createSummaryCard(summary) {
    const card = document.createElement('div');
    card.className = 'audio-card';
    
    const date = new Date(summary.created_at).toLocaleString('ja-JP');
    
    card.innerHTML = `
      <div class="audio-text">${summary.text}</div>
      <audio controls src="${summary.audio_url}">
        お使いのブラウザは audio タグをサポートしていません。
      </audio>
      <div class="audio-meta">
        <small>作成日時: ${date}</small>
      </div>
    `;
    
    return card;
  }
  
  /**
   * テキストから音声を生成する
   */
  async generateSpeech() {
    const text = this.summaryText.value.trim();
    const voiceId = this.voiceSelect.value;
    
    if (!text) {
      this.showError('テキストを入力してください。');
      return;
    }
    
    try {
      // UI更新
      this.setLoading(true);
      
      // 音声生成
      const audioBlob = await this.elevenlabs.generateSpeech(text, voiceId);
      
      // 現在の状態を保存
      this.currentAudioBlob = audioBlob;
      this.currentText = text;
      
      // プレビュー表示
      this.showPreview(text, audioBlob);
      
      // UI更新
      this.setLoading(false);
    } catch (error) {
      console.error('Error generating speech:', error);
      this.showError('音声の生成中にエラーが発生しました。');
      this.setLoading(false);
    }
  }
  
  /**
   * 音声プレビューを表示する
   * @param {string} text - テキスト
   * @param {Blob} audioBlob - 音声データ
   */
  showPreview(text, audioBlob) {
    // テキスト表示
    this.previewText.textContent = text;
    
    // 音声設定
    const audioUrl = URL.createObjectURL(audioBlob);
    this.previewAudio.src = audioUrl;
    
    // セクション表示
    this.previewSection.classList.remove('hidden');
    
    // 自動再生
    this.previewAudio.play();
  }
  
  /**
   * 要約を保存する
   */
  async saveSummary() {
    if (!this.currentAudioBlob || !this.currentText) {
      this.showError('保存する音声がありません。');
      return;
    }
    
    try {
      // UI更新
      this.setLoading(true);
      
      // ファイル名の作成
      const fileName = `summary_${Date.now()}.mp3`;
      
      // Blobをファイルに変換
      const audioFile = this.elevenlabs.blobToFile(this.currentAudioBlob, fileName);
      
      // Supabaseにアップロード
      const audioUrl = await this.supabase.uploadAudio(audioFile);
      
      // データベースに保存
      await this.supabase.saveSummary(this.currentText, audioUrl);
      
      // 要約リストを更新
      await this.loadSummaries();
      
      // UI更新
      this.setLoading(false);
      this.showSuccess('要約が保存されました。');
    } catch (error) {
      console.error('Error saving summary:', error);
      this.showError('要約の保存中にエラーが発生しました。');
      this.setLoading(false);
    }
  }
  
  /**
   * ローディング状態を設定する
   * @param {boolean} isLoading - ローディング中かどうか
   */
  setLoading(isLoading) {
    if (isLoading) {
      this.loadingIndicator.classList.remove('hidden');
      this.generateBtn.disabled = true;
      this.saveBtn.disabled = true;
    } else {
      this.loadingIndicator.classList.add('hidden');
      this.generateBtn.disabled = false;
      this.saveBtn.disabled = false;
    }
  }
  
  /**
   * エラーメッセージを表示する
   * @param {string} message - エラーメッセージ
   */
  showError(message) {
    alert(`エラー: ${message}`);
  }
  
  /**
   * 成功メッセージを表示する
   * @param {string} message - 成功メッセージ
   */
  showSuccess(message) {
    alert(message);
  }
}

// アプリケーションの起動
document.addEventListener('DOMContentLoaded', () => {
  new App();
});

export default App;
