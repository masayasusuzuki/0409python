# ElevenLabs 音声要約アプリ セットアップガイド

このドキュメントでは、ElevenLabs 音声要約アプリのセットアップ方法について詳しく説明します。

## 前提条件

- ElevenLabs アカウント（APIキーが必要）
- Supabase アカウント（プロジェクトの作成が必要）
- ウェブサーバー（ローカル開発サーバーまたはホスティングサービス）

## 1. ElevenLabs APIキーの取得

1. [ElevenLabs](https://elevenlabs.io/) にアクセスし、アカウントを作成またはログインします。
2. ダッシュボードから「API」セクションに移動します。
3. APIキーをコピーします。このキーは後で `config.js` ファイルに設定します。

## 2. Supabaseプロジェクトの設定

### 2.1 プロジェクトの作成

1. [Supabase](https://supabase.com/) にアクセスし、アカウントを作成またはログインします。
2. 「New Project」をクリックして新しいプロジェクトを作成します。
3. プロジェクト名を入力し、リージョンを選択して「Create new project」をクリックします。
4. プロジェクトの作成が完了するまで待ちます（数分かかる場合があります）。

### 2.2 テーブルの作成

1. Supabaseダッシュボードの「Table Editor」に移動します。
2. 「Create a new table」をクリックします。
3. テーブル名を `summaries` に設定します。
4. 以下のカラムを追加します：

| カラム名 | データ型 | デフォルト値 | プライマリ | Nullable |
|---------|---------|------------|----------|----------|
| id | uuid | gen_random_uuid() | はい | いいえ |
| text | text | | いいえ | いいえ |
| audio_url | text | | いいえ | いいえ |
| created_at | timestamptz | now() | いいえ | いいえ |

5. 「Save」をクリックしてテーブルを作成します。

### 2.3 ストレージバケットの作成

1. Supabaseダッシュボードの「Storage」に移動します。
2. 「Create a new bucket」をクリックします。
3. バケット名を `audio_summaries` に設定します。
4. 「Public」オプションを有効にして、音声ファイルに公開アクセスできるようにします。
5. 「Create bucket」をクリックします。

### 2.4 APIキーとURLの取得

1. Supabaseダッシュボードの「Settings」→「API」に移動します。
2. 「Project URL」と「anon/public」キーをコピーします。これらは後で `config.js` ファイルに設定します。

## 3. アプリケーションの設定

### 3.1 config.jsの設定

`config.js` ファイルを開き、以下の情報を設定します：

```javascript
const config = {
  // ElevenLabs API設定
  elevenlabs: {
    apiKey: 'YOUR_ELEVENLABS_API_KEY', // ElevenLabsのAPIキーを設定
    apiUrl: 'https://api.elevenlabs.io/v1',
    voiceId: 'pNInz6obpgDQGcFmaJgB', // デフォルトの音声ID（Rachel）
  },
  
  // Supabase設定
  supabase: {
    url: 'YOUR_SUPABASE_URL', // SupabaseプロジェクトのURL
    apiKey: 'YOUR_SUPABASE_API_KEY', // SupabaseのAPIキー（anon/public）
    bucket: 'audio_summaries', // 音声ファイルを保存するバケット名
    tableName: 'summaries', // 要約データを保存するテーブル名
  }
};
```

- `YOUR_ELEVENLABS_API_KEY` を実際のElevenLabs APIキーに置き換えます。
- `YOUR_SUPABASE_URL` を実際のSupabaseプロジェクトURLに置き換えます。
- `YOUR_SUPABASE_API_KEY` を実際のSupabase APIキー（anon/public）に置き換えます。

## 4. アプリケーションの実行

### 4.1 ローカル開発サーバーでの実行

1. プロジェクトディレクトリに移動します。
2. 以下のコマンドを実行して、シンプルなHTTPサーバーを起動します：

```bash
# Pythonを使用する場合
python -m http.server 8000

# Node.jsを使用する場合
npx http-server -p 8000
```

3. ブラウザで `http://localhost:8000` にアクセスします。

### 4.2 ホスティングサービスでの実行

プロジェクトファイルを任意のウェブホスティングサービス（GitHub Pages、Netlify、Vercelなど）にアップロードして実行することもできます。

## 5. トラブルシューティング

### 5.1 CORS関連の問題

ElevenLabs APIやSupabaseへのリクエストでCORSエラーが発生する場合は、以下の対策を試してください：

1. ブラウザの開発者ツールでエラーメッセージを確認します。
2. Supabaseの場合、プロジェクト設定でCORSを適切に設定します（「Settings」→「API」→「CORS」）。
3. ElevenLabs APIの場合、サーバーサイドプロキシを使用するか、ElevenLabsのサポートに問い合わせてください。

### 5.2 APIキーの問題

APIキーが正しく機能しない場合は、以下を確認してください：

1. APIキーが正確にコピーされていることを確認します。
2. ElevenLabsの場合、APIキーの使用制限を確認します。
3. Supabaseの場合、正しいキー（anon/public）を使用していることを確認します。

## 6. セキュリティに関する注意事項

- このアプリケーションは、フロントエンドでAPIキーを使用しています。本番環境では、APIキーを保護するためにバックエンドプロキシを使用することを検討してください。
- Supabaseのセキュリティルールを適切に設定して、データへの不正アクセスを防止してください。
