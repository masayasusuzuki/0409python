// config.js
// アプリケーションの設定情報

const config = {
  // ElevenLabs API設定
  elevenlabs: {
    apiKey: 'YOUR_ELEVENLABS_API_KEY', // ElevenLabsのAPIキーを設定
    apiUrl: 'https://api.elevenlabs.io/v1',
    voiceId: 'pNInz6obpgDQGcFmaJgB', // デフォルトの音声ID（Rachel）
  },
  
  // Supabase設定
  supabase: {
    url: 'YOUR_SUPABASE_URL', // SupabaseプロジェクトのURL
    apiKey: 'YOUR_SUPABASE_API_KEY', // SupabaseのAPIキー（anon/public）
    bucket: 'audio_summaries', // 音声ファイルを保存するバケット名
    tableName: 'summaries', // 要約データを保存するテーブル名
  }
};

export default config;
