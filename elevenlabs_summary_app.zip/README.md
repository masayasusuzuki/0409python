# ElevenLabs 音声要約アプリ

このアプリケーションは、ElevenLabs APIを使用してテキストから高品質な音声を生成し、Supabaseを使用してデータを管理するウェブアプリケーションです。

## 機能

- ElevenLabs APIを使用したテキストから音声への変換
- Supabaseを使用した音声ファイルとテキストデータの管理
- レスポンシブなウェブインターフェースでの音声再生と要約表示

## ファイル構成

- `index.html` - メインのHTMLファイル
- `styles.css` - CSSスタイルシート
- `app.js` - メインのJavaScriptファイル
- `elevenlabs-api.js` - ElevenLabs API連携用のJavaScriptモジュール
- `supabase-client.js` - Supabase連携用のJavaScriptモジュール
- `config.js` - 設定ファイル（APIキーなど）

## 使用技術

- HTML5
- CSS3
- JavaScript (ES6+)
- ElevenLabs API
- Supabase (PostgreSQL + Storage)

## セットアップ方法

1. ElevenLabs APIキーを取得
2. Supabaseプロジェクトを作成し、必要なテーブルを設定
3. `config.js`ファイルに必要なAPIキーとURLを設定
4. ウェブサーバーでアプリケーションを実行

詳細な設定方法は各ファイルのコメントを参照してください。
